//
//  ViewController.swift
//  PickerViewDemo
//
//  Created by Nirav Joshi on 08/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    @IBOutlet weak var txtDetails: UITextField!
    @IBOutlet weak var PickerView: UIPickerView!
    var pickerData: [[String]] = [[String]]()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        pickerData =  [["1", "2", "3", "4"],
                       ["a", "b", "c", "d"],
                       ["!", "#", "$", "%"],
                       ["w", "x", "y", "z"]]
        
        // Connect data
        self.PickerView.dataSource = self
        self.PickerView.delegate = self

    }

    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 4;
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 4
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return pickerData[component][row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        print(pickerData[component][row])
    }
    
    
}

